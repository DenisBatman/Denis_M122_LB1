set search_path to google_scraper;
SELECT * from search_results;